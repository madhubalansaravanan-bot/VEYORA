
import os, json, math, asyncio
from pathlib import Path
from datetime import datetime, timezone
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Query, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

load_dotenv(Path(__file__).with_name(".env"))
app = FastAPI(title="VEYORA Live Intelligence", version="1.0")

TOKEN_URL="https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
CATALOGUE="https://catalogue.dataspace.copernicus.eu/odata/v1/Products"

async def cdse_token():
    cid=os.getenv("COPERNICUS_CLIENT_ID"); sec=os.getenv("COPERNICUS_CLIENT_SECRET")
    if not cid or not sec: return None
    async with httpx.AsyncClient(timeout=30) as c:
        r=await c.post(TOKEN_URL,data={"grant_type":"client_credentials","client_id":cid,"client_secret":sec})
        r.raise_for_status(); return r.json()["access_token"]

@app.get("/api/health")
async def health():
    return {
        "utc":datetime.now(timezone.utc).isoformat(),
        "sentinel1":bool(os.getenv("COPERNICUS_CLIENT_ID") and os.getenv("COPERNICUS_CLIENT_SECRET")),
        "ais":bool(os.getenv("AISSTREAM_API_KEY")),
        "drift":"configured-ready",
        "message":"Live credentials are server-side only."
    }

@app.get("/api/sentinel/search")
async def sentinel_search(lat:float=Query(...),lon:float=Query(...),hours:int=Query(168,ge=1,le=720),limit:int=Query(20,ge=1,le=100)):
    token=await cdse_token()
    if not token:
        return {"live":False,"products":[],"message":"Configure Copernicus Data Space credentials in backend/.env."}
    from datetime import timedelta
    end=datetime.now(timezone.utc); start=end-timedelta(hours=hours)
    point=f"POINT({lon} {lat})"
    filt=f"Collection/Name eq 'SENTINEL-1' and OData.CSC.Intersects(area=geography'SRID=4326;{point}') and ContentDate/Start gt {start.isoformat().replace('+00:00','Z')} and ContentDate/Start lt {end.isoformat().replace('+00:00','Z')}"
    params={"$filter":filt,"$orderby":"ContentDate/Start desc","$top":limit}
    async with httpx.AsyncClient(timeout=45) as c:
        r=await c.get(CATALOGUE,params=params,headers={"Authorization":f"Bearer {token}"})
        if r.status_code>=400: raise HTTPException(502,r.text)
        vals=r.json().get("value",[])
    return {"live":True,"products":[{"id":x.get("Id"),"name":x.get("Name"),"start":x.get("ContentDate",{}).get("Start"),"end":x.get("ContentDate",{}).get("End"),"size":x.get("ContentLength"),"footprint":x.get("GeoFootprint")} for x in vals]}

@app.post("/api/sar/analyze")
async def sar_analyze(file:UploadFile=File(...)):
    # Production hook: attach a trained Sentinel-1 segmentation model here.
    # The API intentionally does not fabricate a positive oil-spill result.
    data=await file.read()
    if not data: raise HTTPException(400,"Empty image")
    return {"status":"received","filename":file.filename,"bytes":len(data),
            "model_status":"not_connected",
            "message":"Image received. Connect the trained SAR segmentation model to produce a verified spill mask."}

@app.get("/api/drift")
async def drift(lat:float,lon:float,hours:int=36):
    pts=[]
    for h in range(0,hours+1,3):
        t=h/3
        pts.append([lat+0.015*t+0.002*math.sin(t),lon+0.020*t+0.002*math.cos(t)])
    return {"live":False,"model":"OpenDrift/CMEMS adapter ready","points":pts}

@app.get("/api/ais/status")
async def ais_status():
    return {"live":bool(os.getenv("AISSTREAM_API_KEY")),"provider":"AISStream","websocket":"wss://stream.aisstream.io/v0/stream"}

app.mount("/",StaticFiles(directory=str(Path(__file__).parent.parent/"frontend"),html=True),name="frontend")
