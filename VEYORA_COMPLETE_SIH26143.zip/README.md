# VEYORA — Complete SIH26143 Website

## What is implemented
- Professional maritime intelligence dashboard
- Interactive map
- Live-source health status
- Copernicus Data Space Sentinel-1 catalogue search
- SAR image upload endpoint
- AISStream server-side connection configuration
- Drift-model API hook
- Vessel-correlation/ranking UI
- Authority alert/evidence UI
- No fabricated live satellite/AIS observations

## Run
Python 3.11+
1. `pip install -r backend/requirements.txt`
2. Copy `backend/.env.example` to `backend/.env`
3. Add your Copernicus Data Space and AISStream credentials.
4. `uvicorn backend.main:app --reload`
5. Open http://127.0.0.1:8000

## Remaining production model step
The SAR upload endpoint is deliberately a model hook. A trained Sentinel-1 oil-spill segmentation model must be connected before VEYORA claims a spill. This is safer and scientifically defensible than inventing a detection.
