from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import AsyncGenerator

from dotenv import load_dotenv
from geoalchemy2 import Geometry
from sqlalchemy import DateTime, Float, Integer, String, Text, Boolean, JSON, ForeignKey, Index, select, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from geoalchemy2.shape import from_shape, to_shape
from shapely.geometry import Point
import uuid

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://veyora:veyora@localhost:5432/veyora"
)

engine = create_async_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=int(os.getenv("DB_POOL_SIZE", "10")),
    max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "20")),
)

SessionLocal = async_sessionmaker(
    engine,
    expire_on_commit=False,
    class_=AsyncSession,
)


class Base(DeclarativeBase):
    pass


class Investigation(Base):
    __tablename__ = "investigations"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    status: Mapped[str] = mapped_column(String(40), default="open", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)


class SatelliteProduct(Base):
    __tablename__ = "satellite_products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    external_id: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    platform: Mapped[str] = mapped_column(String(50), default="Sentinel-1")
    acquisition_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    acquisition_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    content_length: Mapped[int | None] = mapped_column(Integer)
    footprint = mapped_column(Geometry(geometry_type="GEOMETRY", srid=4326, spatial_index=True))
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class SpillDetection(Base):
    __tablename__ = "spill_detections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    investigation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("investigations.id", ondelete="SET NULL"), nullable=True, index=True)
    satellite_product_id: Mapped[int | None] = mapped_column(ForeignKey("satellite_products.id", ondelete="SET NULL"), nullable=True, index=True)
    filename: Mapped[str] = mapped_column(String(300), nullable=False)
    model_name: Mapped[str] = mapped_column(String(100), default="U-Net")
    model_version: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(40), default="ok")
    spill_detected: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    confidence: Mapped[float | None] = mapped_column(Float)
    area_km2: Mapped[float | None] = mapped_column(Float)
    positive_pixels: Mapped[int | None] = mapped_column(Integer)
    geometry = mapped_column(Geometry(geometry_type="GEOMETRY", srid=4326, spatial_index=True))
    result_json: Mapped[dict] = mapped_column("result", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class DriftRun(Base):
    __tablename__ = "drift_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    investigation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("investigations.id", ondelete="SET NULL"), nullable=True, index=True)
    model: Mapped[str] = mapped_column(String(100), nullable=False)
    direction: Mapped[str] = mapped_column(String(20), nullable=False)
    seed_lat: Mapped[float] = mapped_column(Float, nullable=False)
    seed_lon: Mapped[float] = mapped_column(Float, nullable=False)
    seed_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    hours: Mapped[int] = mapped_column(Integer, nullable=False)
    live: Mapped[bool] = mapped_column(Boolean, default=False)
    result_json: Mapped[dict] = mapped_column("result", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class DriftPoint(Base):
    __tablename__ = "drift_points"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    drift_run_id: Mapped[int] = mapped_column(ForeignKey("drift_runs.id", ondelete="CASCADE"), index=True)
    seq: Mapped[int] = mapped_column(Integer, nullable=False)
    timestamp: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    geometry = mapped_column(Geometry(geometry_type="POINT", srid=4326, spatial_index=True), nullable=False)
    probability: Mapped[float | None] = mapped_column(Float)

    __table_args__ = (
        Index("ix_drift_points_run_seq", "drift_run_id", "seq"),
    )


class Vessel(Base):
    __tablename__ = "vessels"

    mmsi: Mapped[str] = mapped_column(String(20), primary_key=True)
    name: Mapped[str | None] = mapped_column(String(200))
    imo: Mapped[str | None] = mapped_column(String(30))
    callsign: Mapped[str | None] = mapped_column(String(30))
    vessel_type: Mapped[int | None] = mapped_column(Integer)
    latest_lat: Mapped[float | None] = mapped_column(Float)
    latest_lon: Mapped[float | None] = mapped_column(Float)
    latest_sog: Mapped[float | None] = mapped_column(Float)
    latest_cog: Mapped[float | None] = mapped_column(Float)
    latest_heading: Mapped[float | None] = mapped_column(Float)
    latest_seen: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    latest_position = mapped_column(Geometry(geometry_type="POINT", srid=4326, spatial_index=True))
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class AISPosition(Base):
    __tablename__ = "ais_positions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mmsi: Mapped[str] = mapped_column(ForeignKey("vessels.mmsi", ondelete="CASCADE"), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    sog: Mapped[float | None] = mapped_column(Float)
    cog: Mapped[float | None] = mapped_column(Float)
    heading: Mapped[float | None] = mapped_column(Float)
    geometry = mapped_column(Geometry(geometry_type="POINT", srid=4326, spatial_index=True), nullable=False)
    raw_json: Mapped[dict] = mapped_column("raw", JSON, default=dict)

    __table_args__ = (
        Index("ix_ais_positions_mmsi_time", "mmsi", "timestamp"),
    )


class CorrelationResult(Base):
    __tablename__ = "correlation_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    investigation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("investigations.id", ondelete="SET NULL"), nullable=True, index=True)
    spill_detection_id: Mapped[int | None] = mapped_column(ForeignKey("spill_detections.id", ondelete="SET NULL"), nullable=True, index=True)
    vessel_mmsi: Mapped[str] = mapped_column(ForeignKey("vessels.mmsi", ondelete="CASCADE"), index=True)
    origin_lat: Mapped[float] = mapped_column(Float, nullable=False)
    origin_lon: Mapped[float] = mapped_column(Float, nullable=False)
    origin_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    distance_km: Mapped[float | None] = mapped_column(Float)
    time_compatibility: Mapped[float | None] = mapped_column(Float)
    route_alignment: Mapped[float | None] = mapped_column(Float)
    ais_gap_signal: Mapped[float | None] = mapped_column(Float)
    drift_compatibility: Mapped[float | None] = mapped_column(Float)
    score: Mapped[float] = mapped_column(Float, nullable=False)
    classification: Mapped[str] = mapped_column(String(120), nullable=False)
    evidence_json: Mapped[dict] = mapped_column("evidence", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class EvidenceReport(Base):
    __tablename__ = "evidence_reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    investigation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("investigations.id", ondelete="SET NULL"), nullable=True, index=True)
    report_type: Mapped[str] = mapped_column(String(50), default="text")
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS postgis"))
        await conn.run_sync(Base.metadata.create_all)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with SessionLocal() as session:
        yield session


def utc_dt(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def point_geometry(lat: float, lon: float):
    return from_shape(Point(float(lon), float(lat)), srid=4326)
