from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from geoalchemy2.shape import from_shape
from shapely.geometry import shape as make_shape
from sqlalchemy import delete, select, text

from database import (
    AISPosition,
    CorrelationResult,
    DriftPoint,
    DriftRun,
    EvidenceReport,
    Investigation,
    SatelliteProduct,
    SpillDetection,
    SessionLocal,
    Vessel,
    point_geometry,
    utc_dt,
)


def json_geometry_to_geom(value: dict | None):
    if not value:
        return None
    try:
        return from_shape(make_shape(value), srid=4326)
    except Exception:
        return None


async def save_sentinel_products(products: list[dict]) -> int:
    if not products:
        return 0

    count = 0
    async with SessionLocal() as db:
        for item in products:
            ext_id = item.get("id")
            if not ext_id:
                continue

            row = await db.scalar(
                select(SatelliteProduct).where(
                    SatelliteProduct.external_id == ext_id
                )
            )

            if row is None:
                row = SatelliteProduct(
                    external_id=ext_id,
                    name=item.get("name") or ext_id,
                )
                db.add(row)

            row.platform = "Sentinel-1"
            row.acquisition_start = utc_dt(_parse_dt(item.get("start")))
            row.acquisition_end = utc_dt(_parse_dt(item.get("end")))
            row.content_length = item.get("size")
            row.metadata_json = {
                "name": item.get("name"),
                "footprint": item.get("footprint"),
            }

            geometry = item.get("footprint")
            if geometry:
                try:
                    row.footprint = json_geometry_to_geom(geometry)
                except Exception:
                    pass

            count += 1

        await db.commit()

    return count


def _parse_dt(value: str | None):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


async def save_spill_detection(result: dict[str, Any], investigation_id: str | None = None, satellite_product_id: int | None = None) -> int:
    async with SessionLocal() as db:
        row = SpillDetection(
            investigation_id=uuid.UUID(investigation_id) if investigation_id else None,
            satellite_product_id=satellite_product_id,
            filename=result.get("filename") or "upload",
            model_name=result.get("model_name") or "SAR-U-Net",
            model_version=result.get("model_version"),
            status=result.get("status") or "ok",
            spill_detected=bool(result.get("spill", result.get("spill_detected", False))),
            confidence=result.get("confidence"),
            area_km2=result.get("area_km2"),
            positive_pixels=result.get("positive_pixels"),
            geometry=json_geometry_to_geom(result.get("geometry")),
            result_json=result,
        )
        db.add(row)
        await db.commit()
        await db.refresh(row)
        return row.id


async def save_drift_result(result: dict, request: dict) -> int:
    async with SessionLocal() as db:
        row = DriftRun(
            investigation_id=uuid.UUID(request["investigation_id"]) if request.get("investigation_id") else None,
            model=result.get("model") or "unknown",
            direction=request.get("direction", "forward"),
            seed_lat=float(request["lat"]),
            seed_lon=float(request["lon"]),
            seed_time=utc_dt(_parse_dt(request.get("when"))) if isinstance(request.get("when"), str) else utc_dt(request.get("when")),
            hours=int(request.get("hours", 48)),
            live=bool(result.get("live", False)),
            result_json=result,
        )
        db.add(row)
        await db.flush()

        points = result.get("points") or []
        for seq, p in enumerate(points):
            if not isinstance(p, (list, tuple)) or len(p) < 2:
                continue
            db.add(
                DriftPoint(
                    drift_run_id=row.id,
                    seq=seq,
                    geometry=point_geometry(float(p[0]), float(p[1])),
                )
            )

        await db.commit()
        return row.id


async def upsert_vessel_and_position(record: dict[str, Any]) -> None:
    mmsi = str(record["mmsi"])
    timestamp = utc_dt(_parse_dt(record.get("timestamp"))) or datetime.now(timezone.utc)

    async with SessionLocal() as db:
        vessel = await db.get(Vessel, mmsi)
        if vessel is None:
            vessel = Vessel(mmsi=mmsi)
            db.add(vessel)

        vessel.name = record.get("name") or vessel.name
        vessel.imo = record.get("imo") or vessel.imo
        vessel.callsign = record.get("callsign") or vessel.callsign
        vessel.latest_lat = float(record["lat"])
        vessel.latest_lon = float(record["lon"])
        vessel.latest_sog = float(record.get("sog", 0) or 0)
        vessel.latest_cog = float(record.get("cog", 0) or 0)
        vessel.latest_heading = float(record.get("heading", 0) or 0)
        vessel.latest_seen = timestamp
        vessel.latest_position = point_geometry(record["lat"], record["lon"])

        db.add(
            AISPosition(
                mmsi=mmsi,
                timestamp=timestamp,
                sog=record.get("sog"),
                cog=record.get("cog"),
                heading=record.get("heading"),
                geometry=point_geometry(record["lat"], record["lon"]),
                raw_json=record,
            )
        )

        await db.commit()


async def save_correlation_results(
    results: list[dict],
    origin_lat: float,
    origin_lon: float,
    origin_time: str | None = None,
    investigation_id: str | None = None,
    spill_detection_id: int | None = None,
) -> int:
    count = 0
    async with SessionLocal() as db:
        for r in results:
            mmsi = str(r.get("mmsi", ""))
            if not mmsi:
                continue
            if await db.get(Vessel, mmsi) is None:
                continue
            db.add(
                CorrelationResult(
                    investigation_id=uuid.UUID(investigation_id) if investigation_id else None,
                    spill_detection_id=spill_detection_id,
                    vessel_mmsi=mmsi,
                    origin_lat=origin_lat,
                    origin_lon=origin_lon,
                    origin_time=utc_dt(_parse_dt(origin_time)),
                    distance_km=r.get("distance_km", r.get("distance_to_origin_km")),
                    time_compatibility=r.get("time_compatibility"),
                    route_alignment=r.get("route_alignment"),
                    ais_gap_signal=r.get("ais_gap_signal"),
                    drift_compatibility=r.get("drift_compatibility"),
                    score=float(r.get("correlation_score", 0)),
                    classification=r.get("classification") or "candidate",
                    evidence_json=r,
                )
            )
            count += 1
        await db.commit()
    return count


async def save_report(payload: dict, investigation_id: str | None = None) -> int:
    async with SessionLocal() as db:
        row = EvidenceReport(
            investigation_id=uuid.UUID(investigation_id) if investigation_id else None,
            report_type="text",
            payload=payload,
        )
        db.add(row)
        await db.commit()
        await db.refresh(row)
        return row.id


async def nearby_vessels(lat: float, lon: float, radius_km: float = 50, limit: int = 200):
    # ST_DWithin on geography gives distance in meters.
    async with SessionLocal() as db:
        stmt = (
            select(Vessel)
            .where(
                text(
                    "ST_DWithin("
                    "latest_position::geography, "
                    "ST_SetSRID(ST_MakePoint(:lon,:lat),4326)::geography, "
                    ":radius_m)"
                )
            )
            .params(lon=lon, lat=lat, radius_m=radius_km * 1000)
            .limit(limit)
        )
        rows = (await db.execute(stmt)).scalars().all()

        return [
            {
                "mmsi": r.mmsi,
                "name": r.name,
                "lat": r.latest_lat,
                "lon": r.latest_lon,
                "sog": r.latest_sog,
                "cog": r.latest_cog,
                "heading": r.latest_heading,
                "timestamp": r.latest_seen.isoformat() if r.latest_seen else None,
            }
            for r in rows
        ]
