from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from ais import AISManager
from drift import run_opendrift
from report import build_report
from sar import SARAnalyzer
from database import (
    Base, SessionLocal, engine, get_db,
    AISPosition, CorrelationResult, DriftRun, EvidenceReport,
    Investigation, SatelliteProduct, SpillDetection, Vessel,
)
from db_service import (
    save_sentinel_products, save_spill_detection, save_drift_result,
    upsert_vessel_and_position, save_correlation_results, save_report,
    nearby_vessels,
)

BASE = Path(__file__).resolve().parent
FRONTEND = BASE.parent / "frontend"
load_dotenv(BASE / ".env")

app = FastAPI(title="VEYORA Maritime Intelligence API", version="3.0-postgis")
ais_mgr = AISManager()
sar = SARAnalyzer()

TOKEN_URL = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
CATALOGUE_URL = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products"


class DriftRequest(BaseModel):
    lat: float
    lon: float
    hours: int = Field(ge=1, le=168, default=48)
    direction: str = Field(default="forward", pattern="^(forward|backward)$")
    when: datetime | None = None
    investigation_id: str | None = None


class RankRequest(BaseModel):
    origin_lat: float
    origin_lon: float
    origin_time: str | None = None
    drift_points: list[list[float]] = Field(default_factory=list)
    investigation_id: str | None = None
    spill_detection_id: int | None = None


class ReportRequest(BaseModel):
    spill: dict = Field(default_factory=dict)
    origin: dict = Field(default_factory=dict)
    drift_model: str = "unknown"
    vessels: list[dict] = Field(default_factory=list)
    investigation_id: str | None = None


class InvestigationCreate(BaseModel):
    name: str
    status: str = "open"
    metadata: dict = Field(default_factory=dict)


async def cdse_token():
    cid = os.getenv("COPERNICUS_CLIENT_ID")
    sec = os.getenv("COPERNICUS_CLIENT_SECRET")
    if not cid or not sec:
        return None
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            TOKEN_URL,
            data={
                "grant_type": "client_credentials",
                "client_id": cid,
                "client_secret": sec,
            },
        )
        if r.status_code >= 400:
            raise HTTPException(502, f"Copernicus authentication failed: {r.text[:500]}")
        return r.json()["access_token"]


async def ais_db_callback(record: dict):
    try:
        await upsert_vessel_and_position(record)
    except Exception as exc:
        print("AIS database write failed:", exc)


@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.exec_driver_sql("CREATE EXTENSION IF NOT EXISTS postgis")
        await conn.run_sync(Base.metadata.create_all)
    ais_mgr.position_callback = ais_db_callback
    await ais_mgr.start()


@app.on_event("shutdown")
async def shutdown():
    await ais_mgr.stop()
    await engine.dispose()


@app.get("/api/health")
async def health(db: AsyncSession = Depends(get_db)):
    db_ok = True
    try:
        await db.execute(select(1))
    except Exception as exc:
        db_ok = False
        print("DB health failed:", exc)

    return {
        "utc": datetime.now(timezone.utc).isoformat(),
        "database": {
            "connected": db_ok,
            "engine": "PostgreSQL + PostGIS",
        },
        "sentinel1": bool(os.getenv("COPERNICUS_CLIENT_ID") and os.getenv("COPERNICUS_CLIENT_SECRET")),
        "sar_model": sar.connected,
        "ais_configured": bool(os.getenv("AISSTREAM_API_KEY")),
        "ais_status": ais_mgr.status,
        "drift_configured": bool(os.getenv("OPENDRIFT_READERS")),
        "frontend": True,
    }


@app.post("/api/investigations")
async def create_investigation(req: InvestigationCreate, db: AsyncSession = Depends(get_db)):
    row = Investigation(
        name=req.name,
        status=req.status,
        metadata_json=req.metadata,
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return {
        "id": str(row.id),
        "name": row.name,
        "status": row.status,
        "created_at": row.created_at.isoformat(),
    }


@app.get("/api/investigations")
async def list_investigations(db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(select(Investigation).order_by(desc(Investigation.created_at)))).scalars().all()
    return [
        {
            "id": str(r.id),
            "name": r.name,
            "status": r.status,
            "created_at": r.created_at.isoformat(),
            "updated_at": r.updated_at.isoformat(),
        }
        for r in rows
    ]


@app.get("/api/sentinel/search")
async def sentinel_search(
    lat: float = Query(...), lon: float = Query(...),
    hours: int = Query(168, ge=1, le=720), limit: int = Query(20, ge=1, le=100)
):
    token = await cdse_token()
    if not token:
        return {
            "live": False,
            "status": "not_configured",
            "products": [],
            "message": "Configure Copernicus Data Space credentials in backend/.env.",
        }
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=hours)
    point = f"POINT({lon} {lat})"
    filt = (
        "Collection/Name eq 'SENTINEL-1' and "
        f"OData.CSC.Intersects(area=geography'SRID=4326;{point}') and "
        f"ContentDate/Start gt {start.isoformat().replace('+00:00','Z')} and "
        f"ContentDate/Start lt {end.isoformat().replace('+00:00','Z')}"
    )
    async with httpx.AsyncClient(timeout=45) as client:
        r = await client.get(
            CATALOGUE_URL,
            params={"$filter": filt, "$orderby": "ContentDate/Start desc", "$top": limit},
            headers={"Authorization": f"Bearer {token}"},
        )
        if r.status_code >= 400:
            raise HTTPException(502, f"Copernicus catalogue error: {r.text[:500]}")
        vals = r.json().get("value", [])
    products = [
        {
            "id": x.get("Id"),
            "name": x.get("Name"),
            "start": (x.get("ContentDate") or {}).get("Start"),
            "end": (x.get("ContentDate") or {}).get("End"),
            "size": x.get("ContentLength"),
            "footprint": x.get("GeoFootprint"),
        }
        for x in vals
    ]
    await save_sentinel_products(products)
    return {"live": True, "status": "ok", "products": products}


@app.post("/api/sar/analyze")
async def sar_analyze(
    file: UploadFile = File(...),
    investigation_id: str | None = Query(default=None),
):
    data = await file.read()
    if not data:
        raise HTTPException(400, "Empty image")
    try:
        result = sar.analyze(data, file.filename or "upload")
        spill_id = await save_spill_detection(result, investigation_id=investigation_id)
        result["database_id"] = spill_id
        return result
    except Exception as exc:
        raise HTTPException(422, f"SAR analysis failed: {exc}")


@app.post("/api/drift")
async def drift(req: DriftRequest):
    result = run_opendrift(
        req.lat,
        req.lon,
        req.when,
        req.hours,
        req.direction,
        int(os.getenv("DRIFT_PARTICLES", "300")),
    )
    run_id = await save_drift_result(result, req.model_dump(mode="json"))
    result["database_id"] = run_id
    return result


@app.get("/api/ais/status")
async def ais_status():
    return {
        "configured": bool(os.getenv("AISSTREAM_API_KEY")),
        "status": ais_mgr.status,
        "provider": "AISStream",
        "websocket": "wss://stream.aisstream.io/v0/stream",
        "vessels_cached": len(ais_mgr.vessels),
        "bbox": ais_mgr.bbox,
    }


@app.get("/api/ais/vessels")
async def ais_vessels(limit: int = Query(200, ge=1, le=1000), db: AsyncSession = Depends(get_db)):
    rows = (
        await db.execute(
            select(Vessel).order_by(desc(Vessel.latest_seen)).limit(limit)
        )
    ).scalars().all()
    return {
        "status": ais_mgr.status,
        "vessels": [
            {
                "mmsi": v.mmsi,
                "name": v.name,
                "lat": v.latest_lat,
                "lon": v.latest_lon,
                "sog": v.latest_sog,
                "cog": v.latest_cog,
                "heading": v.latest_heading,
                "timestamp": v.latest_seen.isoformat() if v.latest_seen else None,
            }
            for v in rows
        ],
    }


@app.get("/api/ais/nearby")
async def ais_nearby(
    lat: float = Query(...),
    lon: float = Query(...),
    radius_km: float = Query(50, gt=0, le=500),
    limit: int = Query(200, ge=1, le=1000),
):
    return {
        "status": "ok",
        "lat": lat,
        "lon": lon,
        "radius_km": radius_km,
        "vessels": await nearby_vessels(lat, lon, radius_km, limit),
    }


@app.post("/api/ais/import")
async def ais_import(file: UploadFile = File(...)):
    data = await file.read()
    n = ais_mgr.load_csv(data)
    # Persist imported rows immediately.
    for record in ais_mgr.latest(limit=max(n, 1)):
        await upsert_vessel_and_position(record)
    return {"status": "ok", "rows_imported": n, "format": "CSV"}


@app.post("/api/ais/rank")
async def ais_rank(req: RankRequest):
    result = ais_mgr.rank(req.origin_lat, req.origin_lon, req.origin_time, req.drift_points)
    await save_correlation_results(
        result,
        req.origin_lat,
        req.origin_lon,
        req.origin_time,
        req.investigation_id,
        req.spill_detection_id,
    )
    return {
        "status": "ok",
        "stored": True,
        "vessels": result,
    }


@app.post("/api/report")
async def report(req: ReportRequest):
    payload = req.model_dump()
    report_id = await save_report(payload, req.investigation_id)
    content = build_report(payload)
    return Response(
        content=content,
        media_type="text/plain",
        headers={
            "Content-Disposition": "attachment; filename=veyora_evidence_bundle.txt",
            "X-VEYORA-Report-ID": str(report_id),
        },
    )


@app.get("/api/db/stats")
async def db_stats(db: AsyncSession = Depends(get_db)):
    tables = [
        ("investigations", Investigation),
        ("satellite_products", SatelliteProduct),
        ("spill_detections", SpillDetection),
        ("drift_runs", DriftRun),
        ("vessels", Vessel),
        ("ais_positions", AISPosition),
        ("correlation_results", CorrelationResult),
        ("evidence_reports", EvidenceReport),
    ]
    stats = {}
    for name, model in tables:
        stats[name] = len((await db.execute(select(model.id if hasattr(model, 'id') else model))).all()) if name == "vessels" else len((await db.execute(select(model))).scalars().all())
    return stats


app.mount("/", StaticFiles(directory=str(FRONTEND), html=True), name="frontend")
