from __future__ import annotations

import asyncio
import csv
import io
import json
import math
import os
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

import websockets


def haversine_km(lat1, lon1, lat2, lon2):
    p = math.pi / 180
    a = 0.5 - math.cos((lat2-lat1)*p)/2 + math.cos(lat1*p)*math.cos(lat2*p)*(1-math.cos((lon2-lon1)*p))/2
    return 12742 * math.asin(math.sqrt(max(0, a)))


def bearing_deg(lat1, lon1, lat2, lon2):
    p = math.pi/180
    y = math.sin((lon2-lon1)*p) * math.cos(lat2*p)
    x = math.cos(lat1*p)*math.sin(lat2*p) - math.sin(lat1*p)*math.cos(lat2*p)*math.cos((lon2-lon1)*p)
    return (math.degrees(math.atan2(y,x)) + 360) % 360


def angle_diff(a,b):
    d = abs((a-b+180)%360-180)
    return d

class AISManager:
    def __init__(self, position_callback=None):
        self.api_key = os.getenv("AISSTREAM_API_KEY")
        self.bbox = json.loads(os.getenv("AIS_BBOX", "[[8.0,76.0],[16.0,83.5]]"))
        self.vessels: dict[str, dict[str, Any]] = {}
        self.history: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self.task: asyncio.Task | None = None
        self.status = "not_configured" if not self.api_key else "starting"
        self.position_callback = position_callback

    async def start(self):
        if not self.api_key or self.task:
            return
        self.task = asyncio.create_task(self._loop())

    async def stop(self):
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            self.task = None

    async def _loop(self):
        delay = 2
        while True:
            try:
                self.status = "connecting"
                async with websockets.connect(
                    "wss://stream.aisstream.io/v0/stream",
                    compression="deflate",
                    ping_interval=20,
                    ping_timeout=20,
                    max_size=8_000_000,
                ) as ws:
                    await ws.send(json.dumps({
                        "APIKey": self.api_key,
                        "BoundingBoxes": [self.bbox],
                        "FilterMessageTypes": ["PositionReport", "ShipStaticData", "ExtendedClassBPositionReport", "StandardClassBPositionReport"],
                    }))
                    self.status = "live"
                    delay = 2
                    async for raw in ws:
                        event = json.loads(raw.decode() if isinstance(raw, bytes) else raw)
                        self._ingest(event)
            except asyncio.CancelledError:
                raise
            except Exception:
                self.status = "reconnecting"
                await asyncio.sleep(delay)
                delay = min(delay * 2, 60)

    def _ingest(self, event: dict[str, Any]):
        typ = event.get("MessageType")
        meta = event.get("MetaData") or {}
        body = (event.get("Message") or {}).get(typ or "", {})
        if typ not in {"PositionReport", "ExtendedClassBPositionReport", "StandardClassBPositionReport"}:
            # Update static data if present.
            if typ == "ShipStaticData":
                mmsi = str(body.get("UserID") or meta.get("MMSI") or "")
                if mmsi:
                    self.vessels.setdefault(mmsi, {}).update({"mmsi": mmsi, "name": body.get("Name") or meta.get("ShipName")})
            return
        mmsi = str(body.get("UserID") or meta.get("MMSI") or "")
        lat = body.get("Latitude", meta.get("Latitude", meta.get("latitude")))
        lon = body.get("Longitude", meta.get("Longitude", meta.get("longitude")))
        if not mmsi or lat is None or lon is None:
            return
        ts = meta.get("time_utc") or datetime.now(timezone.utc).isoformat()
        rec = {
            "mmsi": mmsi,
            "name": meta.get("ShipName") or self.vessels.get(mmsi, {}).get("name") or f"MMSI {mmsi}",
            "lat": float(lat), "lon": float(lon),
            "sog": float(body.get("Sog", 0) or 0),
            "cog": float(body.get("Cog", 0) or 0),
            "heading": float(body.get("TrueHeading", body.get("Cog", 0)) or 0),
            "timestamp": ts,
        }
        self.vessels[mmsi] = rec
        hist = self.history[mmsi]
        hist.append(rec)
        if self.position_callback:
            try:
                asyncio.create_task(self.position_callback(rec))
            except Exception:
                pass
        if len(hist) > 1000:
            del hist[:-1000]

    def load_csv(self, content: bytes) -> int:
        text = content.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        n = 0
        for row in reader:
            try:
                mmsi = str(row.get("mmsi") or row.get("MMSI"))
                rec = {
                    "mmsi": mmsi,
                    "name": row.get("name") or row.get("ship_name") or f"MMSI {mmsi}",
                    "lat": float(row.get("lat") or row.get("latitude")),
                    "lon": float(row.get("lon") or row.get("longitude")),
                    "sog": float(row.get("sog") or row.get("speed") or 0),
                    "cog": float(row.get("cog") or row.get("course") or 0),
                    "heading": float(row.get("heading") or row.get("true_heading") or 0),
                    "timestamp": row.get("timestamp") or row.get("time_utc") or datetime.now(timezone.utc).isoformat(),
                }
                self.vessels[mmsi] = rec
                self.history[mmsi].append(rec)
                n += 1
            except Exception:
                continue
        return n

    def latest(self, limit=200):
        return list(self.vessels.values())[:limit]

    def rank(self, origin_lat: float, origin_lon: float, origin_time: str | None, drift_points: list[list[float]] | None = None):
        out = []
        for mmsi, vessel in self.vessels.items():
            dist = haversine_km(vessel["lat"], vessel["lon"], origin_lat, origin_lon)
            spatial = math.exp(-dist / 8.0)
            route_bearing = bearing_deg(vessel["lat"], vessel["lon"], origin_lat, origin_lon)
            heading_alignment = max(0.0, 1 - angle_diff(vessel.get("cog", 0), route_bearing) / 180)
            drift_dist = None
            drift_score = 0.0
            if drift_points:
                drift_dist = min(haversine_km(vessel["lat"], vessel["lon"], p[0], p[1]) for p in drift_points)
                drift_score = math.exp(-drift_dist / 10.0)
            hist = self.history.get(mmsi, [])
            gap_hours = 0.0
            if len(hist) >= 2:
                try:
                    times = sorted(datetime.fromisoformat(str(x["timestamp"]).replace("Z", "+00:00")) for x in hist[-20:])
                    gap_hours = max((b-a).total_seconds() for a,b in zip(times, times[1:])) / 3600.0
                except Exception:
                    pass
            gap_score = min(gap_hours / 2.0, 1.0)
            time_score = 0.5
            if origin_time:
                try:
                    ot = datetime.fromisoformat(origin_time.replace("Z", "+00:00"))
                    vt = datetime.fromisoformat(str(vessel["timestamp"]).replace("Z", "+00:00"))
                    time_score = math.exp(-abs((vt-ot).total_seconds()) / (6*3600))
                except Exception:
                    pass
            total = 100 * (0.30*spatial + 0.20*time_score + 0.15*heading_alignment + 0.15*gap_score + 0.20*drift_score)
            out.append({
                **vessel,
                "distance_km": round(dist, 2),
                "time_compatibility": round(time_score*100, 1),
                "route_alignment": round(heading_alignment*100, 1),
                "ais_gap_signal": round(gap_score*100, 1),
                "drift_compatibility": round(drift_score*100, 1),
                "correlation_score": round(total, 1),
                "classification": "high-correlation investigation lead" if total >= 70 else "candidate requiring further review" if total >= 45 else "low-correlation candidate",
            })
        return sorted(out, key=lambda x: x["correlation_score"], reverse=True)
