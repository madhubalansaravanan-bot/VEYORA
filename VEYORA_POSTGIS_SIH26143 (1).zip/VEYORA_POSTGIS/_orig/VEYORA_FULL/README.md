# VEYORA — SIH26143 Full Integration Starter

This project is a real backend/frontend integration scaffold for **VEYORA — See the Spill. Trace the Source.** It does not invent live values.

## 1. Run

Python 3.11+ is recommended.

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r backend/requirements.txt
uvicorn backend.main:app --reload
```

Open `http://127.0.0.1:8000`.

## 2. Credentials

Copy `backend/.env.example` to `backend/.env` and fill server-side values. **Never put keys into the frontend.**

### Copernicus Data Space
Set:
- `COPERNICUS_CLIENT_ID`
- `COPERNICUS_CLIENT_SECRET`

The backend requests a token and searches Sentinel-1 products through the Data Space catalogue.

### AISStream
Set `AISSTREAM_API_KEY` and `AIS_BBOX`.

The server opens the AISStream WebSocket and proxies only normalized vessel data to the frontend. AISStream's documentation explicitly recommends backend-side use because API keys must not be exposed to browsers.

### Drift
Install:

```bash
pip install -r backend/requirements-drift.txt
```

Set `OPENDRIFT_READERS` to one or more valid OpenDrift reader definitions. For Copernicus Marine, the OpenDrift documentation shows `reader_copernicusmarine://...` readers and CMEMS credentials.

## 3. SAR AI

Install:

```bash
pip install -r backend/requirements-ml.txt
```

Train the included U-Net with a directory like:

```text
data/oilspill/
  images/
    sample1.tif
    sample2.tif
  masks/
    sample1.png
    sample2.png
```

Run:

```bash
python backend/train_sar.py --data data/oilspill --epochs 20 --out backend/models/sar_unet.pt
```

For serious SIH evaluation, train/validate/test with a properly georeferenced Sentinel-1 dataset and report held-out metrics. The code intentionally remains `MODEL OFFLINE` until weights exist.

## 4. Historical AIS

The backend accepts CSV with at least:

```text
mmsi,name,lat,lon,sog,cog,heading,timestamp
```

Upload it to `POST /api/ais/import` or adapt the endpoint to your historical AIS provider.

## 5. API surface

- `GET /api/health`
- `GET /api/sentinel/search`
- `POST /api/sar/analyze`
- `POST /api/drift`
- `GET /api/ais/status`
- `GET /api/ais/vessels`
- `POST /api/ais/import`
- `POST /api/ais/rank`
- `POST /api/report`

## 6. Evidence rules

The UI only shows live data after successful backend responses. A missing credential, unavailable provider, or missing ML weights is shown as a setup/unavailable state.

Vessel scores are **investigation leads**, not legal determinations of responsibility. Historical AIS quality, signal gaps, environmental forcing, and image look-alikes require analyst review.
