from __future__ import annotations

import io
import os
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image

from ml.model import SARModel, prepare_channels

try:
    import rasterio
    from rasterio.features import shapes
except Exception:
    rasterio = None
    shapes = None

try:
    from shapely.geometry import shape, mapping
    from shapely.ops import unary_union
    from pyproj import Geod
except Exception:
    shape = mapping = unary_union = Geod = None


class SARAnalyzer:
    def __init__(self):
        path = os.getenv("SAR_MODEL_PATH", "backend/models/sar_unet.pt")
        self.model = SARModel(path, float(os.getenv("SAR_THRESHOLD", "0.5")))

    @property
    def connected(self) -> bool:
        return self.model.connected

    def _read(self, data: bytes, filename: str):
        ext = Path(filename or "").suffix.lower()
        if rasterio is not None and ext in {".tif", ".tiff"}:
            with rasterio.MemoryFile(data) as mem:
                with mem.open() as ds:
                    arr = ds.read()
                    transform = ds.transform
                    crs = str(ds.crs) if ds.crs else None
                    return prepare_channels(arr), transform, crs
        img = Image.open(io.BytesIO(data)).convert("L")
        arr = np.asarray(img)
        return prepare_channels(arr), None, None

    def analyze(self, data: bytes, filename: str) -> dict[str, Any]:
        if not self.connected:
            return {
                "status": "model_not_connected",
                "model_status": "not_connected",
                "filename": filename,
                "message": "Install the ML dependencies and place trained SAR U-Net weights at SAR_MODEL_PATH.",
            }
        chw, transform, crs = self._read(data, filename)
        mask, confidence = self.model.predict(chw)
        area_px = int(mask.sum())
        result: dict[str, Any] = {
            "status": "ok",
            "model_status": "connected",
            "confidence": round(confidence, 4),
            "positive_pixels": area_px,
            "shape": [int(chw.shape[1]), int(chw.shape[2])],
            "crs": crs,
            "georeferenced": bool(transform is not None and crs),
            "spill": False if area_px == 0 else True,
        }
        if area_px == 0:
            result["message"] = "Model found no oil-like region above threshold."
            return result
        if shapes is not None and transform is not None:
            geoms = [shape(g) for g, v in shapes(mask.astype("uint8"), mask=mask, transform=transform) if v == 1]
            if geoms:
                geom = unary_union(geoms)
                gj = mapping(geom)
                result["geometry"] = gj
                if Geod is not None and crs and crs.upper().startswith("EPSG:4326"):
                    geod = Geod(ellps="WGS84")
                    area_m2, _ = geod.geometry_area_perimeter(geom)
                    result["area_km2"] = round(abs(area_m2) / 1e6, 4)
        else:
            result["geometry"] = None
            result["area_km2"] = None
            result["message"] = "Image has no geographic transform; area/polygon cannot be mapped to Earth coordinates."
        return result
