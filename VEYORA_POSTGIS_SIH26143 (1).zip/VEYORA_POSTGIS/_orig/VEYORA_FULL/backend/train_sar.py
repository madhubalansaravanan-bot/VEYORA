from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from PIL import Image
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from ml.model import UNet, prepare_channels

try:
    import rasterio
except Exception:
    rasterio = None


class OilDataset(Dataset):
    def __init__(self, root: str):
        self.root = Path(root)
        self.images = sorted([p for p in (self.root/'images').glob('*') if p.suffix.lower() in {'.png','.jpg','.jpeg','.tif','.tiff','.npy'}])
        self.mask_dir = self.root/'masks'
        if not self.images:
            raise RuntimeError(f"No images found under {self.root/'images'}")

    def _load(self, path: Path):
        if path.suffix.lower() == '.npy':
            return np.load(path)
        if path.suffix.lower() in {'.tif','.tiff'} and rasterio:
            with rasterio.open(path) as ds:
                return ds.read()
        return np.asarray(Image.open(path))

    def __len__(self): return len(self.images)

    def __getitem__(self, idx):
        p = self.images[idx]
        arr = prepare_channels(self._load(p))
        mask = self._load(self.mask_dir/(p.stem + '.png'))
        mask = (np.asarray(mask) > 0).astype('float32')
        x = torch.from_numpy(arr).float()
        y = torch.from_numpy(mask[None, ...]).float()
        return x, y


def dice_loss(logits, target):
    p = torch.sigmoid(logits)
    smooth = 1.0
    inter = (p*target).sum(dim=(1,2,3))
    return 1 - ((2*inter+smooth)/(p.sum(dim=(1,2,3))+target.sum(dim=(1,2,3))+smooth)).mean()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', required=True, help='dataset root with images/ and masks/')
    ap.add_argument('--epochs', type=int, default=20)
    ap.add_argument('--batch', type=int, default=4)
    ap.add_argument('--out', default='backend/models/sar_unet.pt')
    args = ap.parse_args()

    ds = OilDataset(args.data)
    loader = DataLoader(ds, batch_size=args.batch, shuffle=True, num_workers=0)
    model = UNet(2,1)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    bce = nn.BCEWithLogitsLoss()
    model.train()
    for epoch in range(1, args.epochs+1):
        total = 0
        for x,y in loader:
            opt.zero_grad()
            logits = model(x)
            loss = bce(logits,y) + dice_loss(logits,y)
            loss.backward(); opt.step()
            total += loss.item()
        print(f"epoch={epoch:03d} loss={total/max(1,len(loader)):.4f}")
    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), out)
    print(f"saved {out}")


if __name__ == '__main__':
    main()
