from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from ais import AISManager
from drift import run_opendrift
from report import build_report
from sar import SARAnalyzer

BASE = Path(__file__).resolve().parent
FRONTEND = BASE.parent / "frontend"
load_dotenv(BASE / ".env")

app = FastAPI(title="VEYORA Maritime Intelligence API", version="2.0")
ais_mgr = AISManager()
sar = SARAnalyzer()

TOKEN_URL = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
CATALOGUE_URL = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products"


class DriftRequest(BaseModel):
    lat: float
    lon: float
    hours: int = Field(ge=1, le=168, default=48)
    direction: str = Field(default="forward", pattern="^(forward|backward)$")
    when: datetime | None = None


class RankRequest(BaseModel):
    origin_lat: float
    origin_lon: float
    origin_time: str | None = None
    drift_points: list[list[float]] = []


class ReportRequest(BaseModel):
    spill: dict = {}
    origin: dict = {}
    drift_model: str = "unknown"
    vessels: list[dict] = []


async def cdse_token():
    cid = os.getenv("COPERNICUS_CLIENT_ID")
    sec = os.getenv("COPERNICUS_CLIENT_SECRET")
    if not cid or not sec:
        return None
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(TOKEN_URL, data={"grant_type":"client_credentials", "client_id":cid, "client_secret":sec})
        r.raise_for_status()
        return r.json()["access_token"]


@app.on_event("startup")
async def startup():
    await ais_mgr.start()


@app.on_event("shutdown")
async def shutdown():
    await ais_mgr.stop()


@app.get("/api/health")
async def health():
    return {
        "utc": datetime.now(timezone.utc).isoformat(),
        "sentinel1": bool(os.getenv("COPERNICUS_CLIENT_ID") and os.getenv("COPERNICUS_CLIENT_SECRET")),
        "sar_model": sar.connected,
        "ais_configured": bool(os.getenv("AISSTREAM_API_KEY")),
        "ais_status": ais_mgr.status,
        "drift_configured": bool(os.getenv("OPENDRIFT_READERS")),
        "frontend": True,
    }


@app.get("/api/sentinel/search")
async def sentinel_search(
    lat: float = Query(...), lon: float = Query(...),
    hours: int = Query(168, ge=1, le=720), limit: int = Query(20, ge=1, le=100)
):
    token = await cdse_token()
    if not token:
        return {"live": False, "status": "not_configured", "products": [], "message": "Configure Copernicus Data Space credentials in backend/.env."}
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=hours)
    point = f"POINT({lon} {lat})"
    # OData intersection query used by the Data Space catalogue.
    filt = (
        "Collection/Name eq 'SENTINEL-1' and "
        f"OData.CSC.Intersects(area=geography'SRID=4326;{point}') and "
        f"ContentDate/Start gt {start.isoformat().replace('+00:00','Z')} and "
        f"ContentDate/Start lt {end.isoformat().replace('+00:00','Z')}"
    )
    async with httpx.AsyncClient(timeout=45) as client:
        r = await client.get(CATALOGUE_URL, params={"$filter":filt,"$orderby":"ContentDate/Start desc","$top":limit}, headers={"Authorization":f"Bearer {token}"})
        if r.status_code >= 400:
            raise HTTPException(502, f"Copernicus catalogue error: {r.text[:500]}")
        vals = r.json().get("value", [])
    return {"live": True, "status": "ok", "products": [
        {
            "id": x.get("Id"), "name": x.get("Name"),
            "start": (x.get("ContentDate") or {}).get("Start"),
            "end": (x.get("ContentDate") or {}).get("End"),
            "size": x.get("ContentLength"), "footprint": x.get("GeoFootprint")
        } for x in vals
    ]}


@app.post("/api/sar/analyze")
async def sar_analyze(file: UploadFile = File(...)):
    data = await file.read()
    if not data:
        raise HTTPException(400, "Empty image")
    try:
        result = sar.analyze(data, file.filename or "upload")
        return result
    except Exception as exc:
        raise HTTPException(422, f"SAR analysis failed: {exc}")


@app.post("/api/drift")
async def drift(req: DriftRequest):
    return run_opendrift(req.lat, req.lon, req.when, req.hours, req.direction, int(os.getenv("DRIFT_PARTICLES", "300")))


@app.get("/api/ais/status")
async def ais_status():
    return {
        "configured": bool(os.getenv("AISSTREAM_API_KEY")),
        "status": ais_mgr.status,
        "provider": "AISStream",
        "websocket": "wss://stream.aisstream.io/v0/stream",
        "vessels_cached": len(ais_mgr.vessels),
        "bbox": ais_mgr.bbox,
    }


@app.get("/api/ais/vessels")
async def ais_vessels(limit: int = Query(200, ge=1, le=1000)):
    return {"status": ais_mgr.status, "vessels": ais_mgr.latest(limit)}


@app.post("/api/ais/import")
async def ais_import(file: UploadFile = File(...)):
    data = await file.read()
    n = ais_mgr.load_csv(data)
    return {"status": "ok", "rows_imported": n, "format": "CSV"}


@app.post("/api/ais/rank")
async def ais_rank(req: RankRequest):
    return {"status": "ok", "vessels": ais_mgr.rank(req.origin_lat, req.origin_lon, req.origin_time, req.drift_points)}


@app.post("/api/report")
async def report(req: ReportRequest):
    content = build_report(req.model_dump())
    return Response(content=content, media_type="text/plain", headers={"Content-Disposition":"attachment; filename=veyora_evidence_bundle.txt"})


app.mount("/", StaticFiles(directory=str(FRONTEND), html=True), name="frontend")
