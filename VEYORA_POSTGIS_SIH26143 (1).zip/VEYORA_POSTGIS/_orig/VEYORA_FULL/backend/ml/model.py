from __future__ import annotations

import os
from pathlib import Path
from typing import Tuple

import numpy as np

try:
    import torch
    import torch.nn as nn
except Exception:  # optional dependency
    torch = None
    nn = None


class DoubleConv(nn.Module if nn else object):
    def __init__(self, in_ch: int, out_ch: int):
        if nn is None:
            return
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.net(x)


class UNet(nn.Module if nn else object):
    def __init__(self, in_channels: int = 2, out_channels: int = 1, base: int = 32):
        if nn is None:
            return
        super().__init__()
        self.down1 = DoubleConv(in_channels, base)
        self.down2 = DoubleConv(base, base * 2)
        self.down3 = DoubleConv(base * 2, base * 4)
        self.pool = nn.MaxPool2d(2)
        self.mid = DoubleConv(base * 4, base * 8)
        self.up3 = nn.ConvTranspose2d(base * 8, base * 4, 2, 2)
        self.conv3 = DoubleConv(base * 8, base * 4)
        self.up2 = nn.ConvTranspose2d(base * 4, base * 2, 2, 2)
        self.conv2 = DoubleConv(base * 4, base * 2)
        self.up1 = nn.ConvTranspose2d(base * 2, base, 2, 2)
        self.conv1 = DoubleConv(base * 2, base)
        self.out = nn.Conv2d(base, out_channels, 1)

    def forward(self, x):
        a = self.down1(x)
        b = self.down2(self.pool(a))
        c = self.down3(self.pool(b))
        m = self.mid(self.pool(c))
        z = self.up3(m)
        z = self._match(z, c)
        z = self.conv3(torch.cat([z, c], dim=1))
        z = self.up2(z)
        z = self._match(z, b)
        z = self.conv2(torch.cat([z, b], dim=1))
        z = self.up1(z)
        z = self._match(z, a)
        z = self.conv1(torch.cat([z, a], dim=1))
        return self.out(z)

    @staticmethod
    def _match(x, ref):
        dh, dw = ref.shape[-2] - x.shape[-2], ref.shape[-1] - x.shape[-1]
        if dh or dw:
            x = nn.functional.pad(x, [0, dw, 0, dh])
        return x


def robust_normalize(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=np.float32)
    valid = np.isfinite(a)
    if not valid.any():
        return np.zeros_like(a, dtype=np.float32)
    vals = a[valid]
    lo, hi = np.percentile(vals, [2, 98])
    if hi <= lo:
        hi = lo + 1.0
    out = (a - lo) / (hi - lo)
    return np.clip(out, 0, 1).astype(np.float32)


def prepare_channels(arr: np.ndarray) -> np.ndarray:
    """Return CHW float32 with exactly two channels (VV,VH-like)."""
    if arr.ndim == 2:
        a = robust_normalize(arr)
        return np.stack([a, a], axis=0)
    if arr.ndim == 3:
        if arr.shape[0] <= 4:   # bands, H, W
            bands = arr
        else:                   # H, W, bands
            bands = np.transpose(arr, (2, 0, 1))
        if bands.shape[0] == 1:
            a = robust_normalize(bands[0])
            return np.stack([a, a], axis=0)
        return np.stack([robust_normalize(bands[0]), robust_normalize(bands[1])], axis=0)
    raise ValueError(f"Unsupported image array shape: {arr.shape}")


class SARModel:
    def __init__(self, model_path: str, threshold: float = 0.5):
        self.model_path = Path(model_path)
        self.threshold = threshold
        self.model = None
        self.device = "cpu"
        if torch is None:
            return
        if not self.model_path.exists():
            return
        try:
            self.model = UNet(2, 1)
            state = torch.load(self.model_path, map_location="cpu")
            if isinstance(state, dict) and "state_dict" in state:
                state = state["state_dict"]
            self.model.load_state_dict(state)
            self.model.eval()
        except Exception:
            self.model = None

    @property
    def connected(self) -> bool:
        return self.model is not None

    def predict(self, chw: np.ndarray) -> Tuple[np.ndarray, float]:
        if not self.connected:
            raise RuntimeError("SAR model is not connected")
        # Pad to a multiple of 16 because of 4 downsampling stages.
        c, h, w = chw.shape
        ph = (16 - h % 16) % 16
        pw = (16 - w % 16) % 16
        x = np.pad(chw, ((0,0),(0,ph),(0,pw)), mode="reflect")
        tensor = torch.from_numpy(x[None, ...]).float()
        with torch.no_grad():
            prob = torch.sigmoid(self.model(tensor))[0,0].cpu().numpy()
        prob = prob[:h,:w]
        mask = prob >= self.threshold
        conf = float(prob[mask].mean()) if mask.any() else float(prob.max())
        return mask, conf
