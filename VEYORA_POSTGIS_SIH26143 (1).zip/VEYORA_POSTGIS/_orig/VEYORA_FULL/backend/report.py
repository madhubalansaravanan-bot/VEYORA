from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO


def build_report(payload: dict) -> bytes:
    # Keep this dependency-free. Return a plain-text evidence bundle that can be saved as .txt/.json.
    lines = [
        "VEYORA — INVESTIGATION EVIDENCE BUNDLE",
        f"Generated UTC: {datetime.now(timezone.utc).isoformat()}",
        "",
        "Important: vessel ranking is an investigation lead, not a legal finding of responsibility.",
        "",
        f"Spill: {payload.get('spill')}",
        f"Origin: {payload.get('origin')}",
        f"Drift model: {payload.get('drift_model')}",
        "",
        "Vessel candidates:",
    ]
    for i, v in enumerate(payload.get("vessels", []), 1):
        lines.append(f"{i}. {v.get('name')} / MMSI {v.get('mmsi')} — score {v.get('correlation_score')} — {v.get('classification')}")
    return "\n".join(lines).encode("utf-8")
