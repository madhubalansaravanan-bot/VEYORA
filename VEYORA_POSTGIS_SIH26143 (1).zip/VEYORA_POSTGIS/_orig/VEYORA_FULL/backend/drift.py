from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from typing import Any


def _iso(v):
    if isinstance(v, datetime):
        return v.astimezone(timezone.utc).isoformat()
    return v


def run_opendrift(lat: float, lon: float, when: datetime | None, hours: int, direction: str, particles: int = 300) -> dict[str, Any]:
    try:
        from opendrift.models.openoil import OpenOil
    except Exception as e:
        return {"live": False, "status": "unavailable", "model": "OpenOil/OpenDrift", "message": f"OpenDrift not installed: {e}", "points": []}

    reader_spec = os.getenv("OPENDRIFT_READERS", "").strip()
    if not reader_spec:
        return {"live": False, "status": "not_configured", "model": "OpenOil/OpenDrift", "message": "Set OPENDRIFT_READERS to one or more OpenDrift reader definitions.", "points": []}

    try:
        from opendrift.models.openoil import OpenOil
        o = OpenOil(loglevel=50)
        readers = [x.strip() for x in reader_spec.split(",") if x.strip()]
        o.add_readers_from_list(readers)
        seed_time = when or datetime.now(timezone.utc)
        o.seed_elements(lon=lon, lat=lat, number=particles, radius=500, time=seed_time)
        duration = timedelta(hours=hours if direction == "forward" else -hours)
        o.run(duration=duration, time_step=timedelta(minutes=int(os.getenv("DRIFT_TIMESTEP_MIN", "30"))))
        ds = getattr(o, "result", None)
        points = []
        if ds is not None and hasattr(ds, "data_vars") and "lon" in ds and "lat" in ds:
            lon_da = ds["lon"]
            lat_da = ds["lat"]
            # Use particle 0 to produce a lightweight displayed centreline.
            lon_arr = lon_da.values
            lat_arr = lat_da.values
            if lon_arr.ndim == 2:
                lon_arr = lon_arr[:, 0]
                lat_arr = lat_arr[:, 0]
            for lo, la in zip(lon_arr.tolist(), lat_arr.tolist()):
                if lo is not None and la is not None:
                    points.append([float(la), float(lo)])
        if not points:
            return {"live": True, "status": "ok", "model": "OpenOil/OpenDrift", "points": [], "message": "Simulation completed but no display trajectory was returned by this OpenDrift build."}
        return {"live": True, "status": "ok", "model": "OpenOil/OpenDrift", "points": points, "seed_time": _iso(seed_time), "direction": direction}
    except Exception as e:
        return {"live": False, "status": "error", "model": "OpenOil/OpenDrift", "message": str(e), "points": []}
