# VEYORA + PostgreSQL + PostGIS

## Local PostgreSQL option

1. Install PostgreSQL + PostGIS, or use Docker.
2. Create database/user matching `.env`.
3. Copy `.env.example` to `backend/.env`.
4. Install Python dependencies:

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# Linux/macOS
source .venv/bin/activate
pip install -r backend/requirements.txt
```

5. Start PostgreSQL/PostGIS.
6. Start API:

```bash
cd backend
uvicorn main:app --reload
```

## Docker

```bash
cp backend/.env.example backend/.env
# fill your external API keys in backend/.env
docker compose up --build
```

Open `http://127.0.0.1:8000/docs`.

## Stored application data

- investigations
- Sentinel-1 products and footprints
- SAR spill detections and geometries
- drift runs and drift points
- vessels and latest positions
- full AIS position history
- vessel correlation results
- evidence reports

All spatial objects use EPSG:4326 and PostGIS geometry types. Use `ST_DWithin`, `ST_Intersects`, `ST_Distance` etc. for spatial queries.
